# ScientificCalculator-JavaFX
Scientific calculator app using JavaFX

- Java 8.1

##Features:
+ factorial calculations that work on decimal values!
+ display intelligently formats output  

##To Do:
+ implement brackets
+ implement 2nd function mode
+ debug order of operation while chaining operations. Still has minor bugs (maybe don't use on your taxes yet)



![Alt text](/SciCalculatorSS.png?raw=true "")

# Author
Alistair Cooper

[twitter @SwiftComposer](https://www.twitter.com/swiftcomposer.com)

[SwiftCodeComposer.com](https://www.swiftcodecomposer.com)


