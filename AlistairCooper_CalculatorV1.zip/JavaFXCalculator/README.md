# Scientific-Calculator-JavaFX
App demo for parsing JSON from AWS w/ CoreLocation w/ MapKit

- Java 8.1

##Features:
+ 


![Alt text](/MapKitSS.png?raw=true "")

# Author
Alistair Cooper

[twitter @SwiftComposer](https://www.twitter.com/swiftcomposer.com)

[SwiftCodeComposer.com](https://www.swiftcodecomposer.com)


notes 
 function to create number button 
 -> button number, row number, column number, isDoubleWide
 
 function to create binary operation button 
 -> button symbol, row number, column number 
 
 
 What do buttons do 
 - Rand = generates random decimal 
 
 
 
 Event order
 Press 1   ----  makes 1 the current 
 Press + ------ puts the current as the stored   ---  sets operation as "+"
 Press 2 ------ makes 2 the current 
 
 IF
 	Press "="  stored becomes value 1   --- current becomes value 2
 			   does the calculation and displays result
 
 ELSE IF 
 	Press "+"  stored becomes value 1   --- current becomes value 2
 			   does the operation that's previously been entered and displays result
 			   sets current value as the result 
 			    
 
 ----
 
 if there's an operation on the opStack it needs to do that operation 
 THEN set the result as the "current" 
 THEN add the operation to the opStack
-----

The % sign
takes either the current OR the result of the 

--

When u press = the last pressed binary op gets executed on the current


----

Press  2    X     4      =    
Press  2    X     4      X       6
                         DoCalc  result becomes value 1
                         
                         --
=  sets the result to the stored   

----

When you press an operator it checks whether there's an operator in the holding tank. if there isn't it doens't do the calculation
it just set the operator in the operator holding tank for use  when you press the = button

if there is an operator in the holding tank it evaluates the calculation